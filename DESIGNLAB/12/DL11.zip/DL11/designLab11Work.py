import lib601.dist as dist
import lib601.coloredHall as coloredHall
from lib601.coloredHall import *

standardHallway = ['white', 'white', 'green', 'white', 'white']
alternating = ['white', 'green'] * 6
sterile = ['white'] * 16
testHallway = ['chocolate', 'white', 'green', 'white', 'white',
               'green', 'green', 'white',  
               'green', 'white', 'green', 'chocolate']

maxAction = 5
actions = [str(x) for x in range(maxAction) + [-x for x in range(1, maxAction)]]

def makePerfect(hallway = standardHallway):
    return makeSim(hallway, actions, perfectObsNoiseModel,
                   standardDynamics, perfectTransNoiseModel,'perfect')

def makeNoisy(hallway = standardHallway):
    return  makeSim(hallway, actions, noisyObsNoiseModel, standardDynamics,
                    noisyTransNoiseModel, 'noisy')

def makeNoisyKnownInitLoc(initLoc, hallway = standardHallway):
    return  makeSim(hallway, actions, noisyObsNoiseModel, standardDynamics,
                    noisyTransNoiseModel, 'known init',
                    initialDist = dist.DDist({initLoc: 1}))

# Problem 11.1.1
###########################################
def whiteEqGreenObsDist(actualColor):
    if actualColor=='white' or actualColor=='green':
        return dist.DDist({'white': 0.5,'green': 0.5})
    else:
        return dist.DDist({actualColor:1})
def whiteVsGreenObsDist(actualColor):
    if actualColor == 'white':
        return dist.DDist({'green':1.0})
    elif actualColor == 'green':
        return dist.DDist({'white':1.0})
    else :
        return dist.DDist({actualColor:1.0})
def noisyObs(actualColor):
    lists = possibleColors
    lists.remove(actualColor)
    dists ={actualColor: 0.8}
    for i in range(4):
        dists.update({lists[i]:0.05})
    return dist.DDist(dists)
noisyObsModel = makeObservationModel(standardHallway,noisyObs)

# Problem 11.1.2
###########################################
def ringDynamics(loc,act,hallwayLength):
    new_loc = loc + act%hallwayLength      
    if new_loc > hallwayLength - 1
        return(new_loc - hallwayLength)
    elif new_loc < 0
        return(new_loc + hallwayLength)
    else:
        return(new_loc)

def leftSlipTrans(nominalLoc,hallwayLength):
    if nominalLoc == 0:
        return dist.DDist({nominalLoc : 1.0})
    else :
        return dist.DDist({nominalLoc : 0.9,nominalLoc - 1 : 0.1})

def noisyTrans(nominalLoc,hallwayLength):
    if nominalLoc == 0:
        return dist.DDist({nominalLoc : 0.9,nominalLoc + 1: 0.1})
    elif nominalLoc == hallwayLength - 1:
        return dist.DDist({nominalLoc : 0.9,nominalLoc - 1: 0.1})
    else :
        return dist.DDist({nominalLoc: 0.8,nominalLoc + 1: 0.1,nominalLoc - 1: 0.1})
def black(actualColor):
    return dist.DDist({'black': 1.0})
noisyTransModel = makeTransitionModel(standardDynamics,noisyTrans)  




#Problem 11.1.6
#######################################
def sonarHit(distance, sonarPose, robotPose):
    return (robotPose.transformPose(sonarPose.transformPoint(util.Point(distance, 0)))


#Problem 11.1.7
####################################
sonarMax = 1.5
numObservations = 10
sonarPose0 = util.Pose(0.08, 0.134, 1.570796)
def wall((x1, y1), (x2, y2)):
    return util.LineSeg(util.Point(x1,y1), util.Point(x2,y2))
wallSegs = [wall((0, 2), (8, 2)),
            wall((1, 1.25), (1.5, 1.25)),
            wall((2, 1.75), (2.8, 1.75))]
robotPoses = [util.Pose(0.5, 0.5, 0),
             util.Pose(1.25, 0.5, 0),
             util.Pose(1.75, 1.0, 0),
             util.Pose(2.5, 1.0, 0)]
def discreteSonar(snoarReading):
    final = int(snoarReading / (sonarMax / numObservations))
    return util.clip(final, 0, 9)

def idealReadings(wallSegs, robotPoses):
    discreteDiss = []
    for i in range(4):
        discreteDisstem = []
        StartPoint = sonarHit(0, sonarPose0, robotPoses[i])
        EndPoint = sonarHit(sonarMax, sonarPose0, robotPoses[i])
        sonarSeg = util.LineSeg(StartPoint, EndPoint)
        for j in range(3):            
            if sonarSeg.intersection(wallSegs[j]) == False:
                intersection = None
            else :
                intersection = sonarSeg.intersection(wallSegs[j])
            if intersection == None :
                distance = sonarMax
            else :
                distance = sonarStartPoint.distance(intersection)
            discreteDisstem.append(discreteSonar(distance))
        discreteDiss.append(min(discreteDisstem))
    return discreteDiss  


#n = makeNoisy()     
#n.run(20)




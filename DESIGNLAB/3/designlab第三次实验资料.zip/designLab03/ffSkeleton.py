import lib601.sm as sm

class FollowFigure(sm.SM):
    pass

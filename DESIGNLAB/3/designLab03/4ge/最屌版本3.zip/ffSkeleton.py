import lib601.sm as sm
import lib601.util as util

from secretMessage import secret
squarePoints = secret
new_list = squarePoints[:]
# squarePoints = [util.Point(0.5, 0.5), util.Point(0.0, 1.0),
#                 util.Point(-0.5, 0.5), util.Point(0.0, 0.0)]

import dynamicMoveToPointSkeleton
class FollowFigure(sm.SM):
    def __init__(self):
        self.startState = 'False'
    def getNextValues(self, state, inp):
        global temp
        global squarePoints
        state = dynamicMoveToPointSkeleton.temp
        if state == 'True':
            if len(new_list) > 1:
                del new_list[0]
                return '', (new_list[0], inp)
            else:
                return '', (new_list[0], inp)
        if state == 'False':
            return '', (new_list[0], inp)

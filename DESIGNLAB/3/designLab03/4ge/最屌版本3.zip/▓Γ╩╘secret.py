from secretMessage import secret
sque = secret
print('sque',sque)
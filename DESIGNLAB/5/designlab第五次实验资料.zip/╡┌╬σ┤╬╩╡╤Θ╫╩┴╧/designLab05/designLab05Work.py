import lib601.sig as sig
import lib601.ts as ts
import lib601.poly as poly
import lib601.sf as sf

def controller(k):
   pass

def plant1(T):
   pass

def plant2(T, V):
   pass

def wallFollowerModel(k, T, V):
   pass

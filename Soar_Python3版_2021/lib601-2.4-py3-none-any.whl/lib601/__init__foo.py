# uncompyle6 version 3.6.4
# Python bytecode 2.6 (62161)
# Decompiled from: Python 3.7.6 (tags/v3.7.6:43364a7ae0, Dec 19 2019, 00:42:30) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: c:\Users\robot\Desktop\newversion\codesandbox\lib601\__init__foo.py
# Compiled at: 2011-01-02 23:08:58
pass
__doc__ = '\nRead in a soar simulated world file and represent its walls as lists\nof line segments.\n'
import lib601.util as util
from imp import reload
reload(util)

class SoarWorld:
    """
    Represents a world in the same way as the soar simulator
    """

    def __init__(self, path):
        """
        @param path: String representing location of world file
        """
        global world
        self.walls = []
        self.wallSegs = []
        world = self
        #execfile(path)
        with open(path,'r') as f:
            exec(f.read())
        (dx, dy) = self.dimensions
        wall((0, 0), (0, dy))
        wall((0, 0), (dx, 0))
        wall((dx, 0), (dx, dy))
        wall((0, dy), (dx, dy))

    def initialLoc(self, x, y):
        self.initialRobotLoc = util.Point(x, y)

    def dims(self, dx, dy):
        self.dimensions = (
         dx, dy)

    def addWall(self, xlo_ylo, xhi_yhi):#uploaded tuple parameter unpacking
        xlo,ylo = xlo_ylo
        xhi,yhi = xhi_yhi
        self.walls.append((util.Point(xlo, ylo), util.Point(xhi, yhi)))
        self.wallSegs.append(util.LineSeg(util.Point(xlo, ylo), util.Point(xhi, yhi)))


def initialRobotLoc(x, y):
    world.initialLoc(x, y)


def dimensions(x, y):
    world.dims(x, y)


def wall(p1, p2):
    world.addWall(p1, p2)

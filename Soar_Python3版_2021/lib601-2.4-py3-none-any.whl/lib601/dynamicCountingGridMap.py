import lib601.gridMap as gridMap, math, lib601.util as util, lib601.colors as colors

class DynamicCountingGridMap(gridMap.GridMap):
    """
    Implements the C{GridMap} interface.
    """

    def __init__(self, xMin, xMax, yMin, yMax, gridSquareSize):
        """
        @param fixMe
        """
        self.xMin = xMin
        self.xMax = xMax
        self.yMin = yMin
        self.yMax = yMax
        self.xN = int(math.ceil(self.xMax / gridSquareSize))
        self.yN = int(math.ceil(self.yMax / gridSquareSize))
        self.xStep = gridSquareSize
        self.yStep = gridSquareSize
        self.xMax = gridSquareSize * self.xN
        self.yMax = gridSquareSize * self.yN
        self.grid = util.make2DArray(self.xN, self.yN, 0)
        self.growRadiusInCells = int(math.ceil(gridMap.robotRadius / gridSquareSize))
        self.makeWindow()
        self.drawWorld()

    def squareColor(self, indices):
        """
        @param documentme
        """
        (xIndex, yIndex) = indices
        maxValue = 10
        storedValue = util.clip(self.grid[xIndex][yIndex], -maxValue, maxValue)
        v = util.clip((maxValue - storedValue) / maxValue, 0, 1)
        s = util.clip((storedValue + maxValue) / maxValue, 0, 1)
        if self.robotCanOccupy(indices):
            hue = colors.greenHue
        else:
            hue = colors.redHue
        return colors.RGBToPyColor(colors.HSVtoRGB(hue, 0.2 + 0.8 * s, v))

    def setCell(self, x_y):#updated tuple parameter unpacking
        xIndex,yIndex = x_y
        self.grid[xIndex][yIndex] += 2
        self.drawSquare((xIndex, yIndex))

    def clearCell(self, x_y):#updated tuple parameter unpacking
        xIndex, yIndex = x_y
        self.grid[xIndex][yIndex] -= 0.25
        self.drawSquare((xIndex, yIndex))

    def occupied(self, x_y):#updated tuple parameter unpacking
        xIndex, yIndex = x_y
        return self.grid[xIndex][yIndex] > 2

    def robotCanOccupy(self, x_y):#updated tuple parameter unpacking
        xIndex, yIndex = x_y
        for dx in range(0, self.growRadiusInCells + 1):
            for dy in range(0, self.growRadiusInCells + 1):
                xPlus = util.clip(xIndex + dx, 0, self.xN - 1)
                xMinus = util.clip(xIndex - dx, 0, self.xN - 1)
                yPlus = util.clip(yIndex + dy, 0, self.yN - 1)
                yMinus = util.clip(yIndex - dy, 0, self.yN - 1)
                if self.grid[xPlus][yPlus] > 2 or self.grid[xPlus][yMinus] > 2 or self.grid[xMinus][yPlus] > 2 or self.grid[xMinus][yMinus] > 2:
                    return False

        return True

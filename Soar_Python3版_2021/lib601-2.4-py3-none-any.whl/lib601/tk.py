import tkinter
#if not globals().has_key('__tk_inited'):
if '__tk_inited' not in globals():#updated 'dict' object has no attribute 'has_key'
    __tk_inited = False

def init():
    global __tk_inited
    if not __tk_inited:
        w = tkinter.Tk()
        w.withdraw()


def setInited():
    global __tk_inited
    __tk_inited = True
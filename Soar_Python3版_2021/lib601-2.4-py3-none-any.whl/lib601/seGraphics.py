
__doc__ = 'State estimator that calls procedures for visualization or debugging'
import lib601.seFast as seFast
from importlib import reload
reload(seFast)
observationHook = None
beliefHook = None

class StateEstimator(seFast.StateEstimator):
    """By default, this is the same as C{seFast.StateEstimator}.  If
    the attributes C{observationHook} or C{beliefHook} are defined,
    then as well as doing C{getNextValues} from
    C{seFast.StateEstimator}, it calls the hooks.
    """

    def getNextValues(self, state, inp):
        if observationHook and inp:
            observationHook(inp[0], self.model.observationDistribution)
        result = seFast.StateEstimator.getNextValues(self, state, inp)
        if beliefHook:
            beliefHook(result[0])
        return result

peak = 5 
halfWith = 3
for i in range(0,halfWith):
        list[peak+i] = 5
        #float(halfWith-i)/(halfWith*halfWith)
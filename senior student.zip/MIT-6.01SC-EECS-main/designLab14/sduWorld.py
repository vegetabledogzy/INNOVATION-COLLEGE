dimensions(3,4)
wall((1,0),(1,2))
wall((2,0),(2,3))
wall((1,3),(2,3))

initialRobotLoc(0.5, 0.5)
